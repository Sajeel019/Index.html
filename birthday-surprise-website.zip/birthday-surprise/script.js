const heartField = document.getElementById("heart-field");
const music = document.getElementById("bg-music");
const toast = document.getElementById("toast");
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function makeHeart() {
  const heart = document.createElement("span");
  heart.className = "float-heart";
  heart.textContent = ["♡", "♥", "✧", "💕"][Math.floor(Math.random() * 4)];
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.fontSize = (14 + Math.random() * 20) + "px";
  heart.style.animationDuration = (6 + Math.random() * 6) + "s";
  heartField.appendChild(heart);
  setTimeout(() => heart.remove(), 12500);
}
setInterval(makeHeart, 650);

document.getElementById("open-surprise").addEventListener("click", () => {
  document.getElementById("cake-section").scrollIntoView({ behavior: "smooth" });
  // Browsers require a visitor's click before audio can start.
  music.play().then(() => showToast("A little music, just for you 🎶"))
    .catch(() => showToast("Your surprise is ready! Add your music file to hear it 🎵"));
});

const candles = [...document.querySelectorAll(".candle")];
candles.forEach(candle => candle.addEventListener("click", () => {
  candle.classList.toggle("blown");
  if (candles.every(item => item.classList.contains("blown"))) {
    document.getElementById("wish-message").textContent = "Wish made! May all your dreams come true 🤍";
    showToast("Make a wish, birthday girl! ✨");
    for (let i = 0; i < 24; i++) setTimeout(makeHeart, i * 70);
  }
}));

document.getElementById("wish-btn").addEventListener("click", () => {
  document.getElementById("wish-message").textContent = "I hope every beautiful wish finds its way to you. 🤍";
  showToast("Your wish is sent to the universe 💫");
});

document.getElementById("envelope").addEventListener("click", function () {
  this.classList.add("open");
  document.getElementById("love-letter").classList.add("show");
  document.getElementById("love-letter").setAttribute("aria-hidden", "false");
  setTimeout(() => document.getElementById("love-letter").scrollIntoView({ behavior: "smooth", block: "center" }), 350);
  for (let i = 0; i < 12; i++) setTimeout(makeHeart, i * 100);
});

document.getElementById("again-btn").addEventListener("click", () => {
  candles.forEach(candle => candle.classList.remove("blown"));
  document.getElementById("wish-message").textContent = "Three little candles, one big wish ✨";
  document.getElementById("envelope").classList.remove("open");
  document.getElementById("love-letter").classList.remove("show");
  document.getElementById("love-letter").setAttribute("aria-hidden", "true");
  document.getElementById("welcome").scrollIntoView({ behavior: "smooth" });
  showToast("A fresh little beginning, just for you 💗");
});
